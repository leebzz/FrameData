package Final;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;

public class Runner {
	Scanner input;
	Game game;
	
	public Runner()
	{
		input = new Scanner(System.in);
		game = new Game();
		run();
	}
	
	private void run()
	{
		char choice = 'z';
		do
		{
			printMenu();
			choice = input.nextLine().toLowerCase().charAt(0);
			if(choice == 'v')
			{
				viewCharacter();
			}
			else if(choice == 'e')
			{
				editCharacter();
			}
			else if(choice =='a')
			{
				addCharacter();
			}
			else if(choice =='r')
			{
				removeCharacter();
			}
			else if(choice =='q')
			{
				System.out.println("Goodbye!");
			}
			else
			{
				System.out.println("Not a valid choice! please try again.");
			}
			
		}
		while(choice !='q');
		
	}
	
	private void printMenu()
	{
		System.out.println("(V) View chatacter");
		System.out.println("(E) Edit character");
		System.out.println("(A) Add character");
		System.out.println("(R) Remove character");
		System.out.println("(Q) Quit");
	}
	
	private void viewCharacter()
	{
		System.out.println(selectCharacter("view"));
		
		System.out.println("\nPress enter to go back to the main menu");
		input.nextLine();
	}
	
	private void editCharacter()
	{
		GameCharacter chaaracter = selectCharacter("edit");
		//TODO
		
		System.out.println("\nPress enter to go back to the main menu");
		input.nextLine();
	}
	
	private void checkForEdits(GameCharacter chatacter) {
		
	}
	
	private void addCharacter()
	{
		System.out.println("What is the name of the character?");
		String name = input.nextLine();
		System.out.println("What are some tips when using this character?");
		String usingTips = input.nextLine();
		System.out.println("What are some tips when playing against this character?");
		String dealWithTips = input.nextLine();
		
		System.out.println("Would you like to add a move to the character? (y/n)");
		char answer = input.nextLine().toLowerCase().charAt(0);
		ArrayList<Move> moves = new ArrayList<Move>();
		while(answer == 'y') {
			moves.add(creatMove());
			System.out.println("Would you like to add another move to the character? (y/n)");
			answer = input.nextLine().toLowerCase().charAt(0);
			
		}
		game.addCharacter(new GameCharacter(name,moves,usingTips, dealWithTips));
		System.out.println(name = " was succssfully added!");
		
		System.out.println("\nPress enter to go back to the main menue...");
		input.nextLine();
	}
	
	private Move creatMove() {
		System.out.println("what is the name of the move?");
		String name = input.nextLine();
		System.out.println("what is the input to preform the move?");
		String moveInput = input.nextLine();
		System.out.println("what is the startup time of the move?");
		double startUpTime = input.nextDouble();
		System.out.println("what is the active time of the move?");
		double activeTime = input.nextDouble();
		System.out.println("what is the recovery time of the move?");
		double recoveryTime = input.nextDouble();
		System.out.println("what is the damage of the move?");
		double damage = input.nextDouble();
		System.out.println("what is the block stun time of the move?");
		double blockStunTime = input.nextDouble();
		System.out.println("what is the hit stun of the move?");
		double hitStunTime = input.nextDouble();
		
		input.nextLine();
		System.out.println(name + " move has been added successfully!");
		return new Move(name,moveInput,startUpTime, activeTime, recoveryTime, damage,blockStunTime,hitStunTime);
		
	}
	
	private void removeCharacter()
	{
		game.removeCharacter(selectCharacter("remove"));
		System.out.println("Character removed successfully!");
		
		
		System.out.println("\nPress enter to go back to the main menu");
		input.nextLine();
	}
	
	private GameCharacter selectCharacter(String action) {
		if(game.getNumCharacters() > 0) {
			displayAllCharacters();
			System.out.println("Enter the name of the character you would like to " + action + ": ");
			return validateCharacterName();
			
			}
		    System.out.println("There are no  characters to " + action + ".");
		    return null;
		
	}
	
	private GameCharacter validateCharacterName()
	{
		
		GameCharacter result = game.getCharacter(input.nextLine().toLowerCase());
		while(result == null) {
			System.out.println("No character exists by that name! Try again: ");
			result = game.getCharacter(input.nextLine().toLowerCase());
		}
		return result;
		
	}
	
	private void displayAllCharacters() {
		System.out.println("These are the available characters: ");
		Set<String> characterNames = game.getCharacterNames();
		for(String name : characterNames) {
			System.out.println(name);
		}
	}
	
	public static void main (String[] args) 
	{
		new Runner();
	}

}
