package Final;

import java.util.ArrayList;

public class GameCharacter {
	private ArrayList<Move> moves;
	private String name;
	private int numMoves;
	private String usingTips;
	private String dealWithTips;
	
	public GameCharacter (String name,ArrayList<Move> moves, String usingTips, String dealWithTips) {
		this.name=name;
		this.moves=moves;
		this.usingTips=usingTips;
		this.dealWithTips=dealWithTips;
	}

	public void addMove(Move move) {
		moves.add(move);
	}
	public void deleteMove(String name) {
		for ( int i = 0; i < moves.size(); i++) {
			if(moves.get(i).getName().equals(name)) {
				moves.remove(i);
				System.out.println(name + " successfully deleted");
				return;
			}
				
		}
		System.out.println("Move " + name + " does not exist on this character");
	}
	public ArrayList<Move> getMoves() {
		return moves;
	}

	public void setMoves(ArrayList<Move> moves) {
		this.moves = moves;
	}

	public int getNumMoves() {
		return numMoves;
	}

	public void setNumMoves(int numMoves) {
		this.numMoves = numMoves;
	}

	public String getUsingTips() {
		return usingTips;
	}

	public void setUsingTips(String usingTips) {
		this.usingTips = usingTips;
	}

	public String getDealWithTips() {
		return dealWithTips;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDealWithTips(String dealWithTips) {
		this.dealWithTips = dealWithTips;
	}
	
	public String toString()
	{
		String result = "";
		result += name;
		result += "\nThis character has " + moves.size() + " moves";
		result += "\nMOVES:\n";
		if(moves.size() == 0) {
			result +="No moves entered\n";
		}
		else {
			for(int i = 0; i<moves.size(); i++) {
				result += moves.get(i).toString() + "\n";
				result += "====================================\n";
			}
		}
		
		result +="\nTips while using this character:";
	    result +="\n"+ usingTips + "\n";
	    result +="\nTips while facing this character:";
	    result +="\n" + dealWithTips + "\n";
	    return result;
	}
}
