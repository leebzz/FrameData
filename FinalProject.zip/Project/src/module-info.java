module Project {
	requires java.desktop;
}