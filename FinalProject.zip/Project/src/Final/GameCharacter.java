/*
 *Final Project*
 * Reilly Stokes, Dalton Thompson, WangMeng Yang
 * 
 * This is a outline for a fighter character creator that could be used in a game like
 * Mortal Kombat or Street Fighter, which is used to add or remove characters to 
 * the games roster. 
 * 
 * The user will enter information and tips for the character that will help
 * players with how the character acts and also ways how other players can 
 * go up against the character. 
 * 
 * It is just an outline, so the user will be prompted to add a few moves to the character and 
 * and then will be able to recall the characters from the array and see who had been added
 * and what moves those characters have.
 * 
 * Users will also be able to add a name to the character for better categorization,
 * the name will always be stored with lower case.
 */

/*
 * This class is used to create the GameCharacters that users will create.
 * Will ask for the information like name, tips for the characters, tips
 * how to play against, and will also show the number of moves the user has given
 * the character.
 */
package Final;

import java.util.ArrayList;

/*
 * creates the variables used for the character information
 */
public class GameCharacter {
	private ArrayList<Move> moves;
	private String name;
	private int numMoves;
	private String usingTips;
	private String dealWithTips;
	
	public GameCharacter (String name,ArrayList<Move> moves, String usingTips, String dealWithTips) {
		this.name=name;
		this.moves=moves;
		this.usingTips=usingTips;
		this.dealWithTips=dealWithTips;
	}

	/*
	 * creates the add move button which is used to add moves to the characters
	 * move set during character creation.
	 */
	public void addMove(Move move) {
		moves.add(move);
	}
	
	/* 
	 * creates the delete move button that can be used to remove a move from 
	 * the characters move set, during character creation.
	 */
	public void deleteMove(String name) {
		for ( int i = 0; i < moves.size(); i++) {
			if(moves.get(i).getName().equals(name)) {
				moves.remove(i);
				System.out.println(name + " successfully deleted");
				return;
			}
				
		}
		System.out.println("Move " + name + " does not exist on this character");
	}
	
	/*
	 * creates the accessors and mutators for the game character.
	 */
	public ArrayList<Move> getMoves() {
		return moves;
	}

	public void setMoves(ArrayList<Move> moves) {
		this.moves = moves;
	}

	public int getNumMoves() {
		return numMoves;
	}

	public void setNumMoves(int numMoves) {
		this.numMoves = numMoves;
	}

	public String getUsingTips() {
		return usingTips;
	}

	public void setUsingTips(String usingTips) {
		this.usingTips = usingTips;
	}

	public String getDealWithTips() {
		return dealWithTips;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDealWithTips(String dealWithTips) {
		this.dealWithTips = dealWithTips;
	}
	
	/*end of the accessors and mutators for the character information***
	 * 
	 * 
	 * create the toString() that will be called in the Runner class.
	 */
	
	public String toString()
	{
		String result = "";
		result += name;
		result += "\nThis character has " + moves.size() + " moves";
		result += "\nMOVES:\n";
		if(moves.size() == 0) {
			result +="No moves entered\n";
		}
		else {
			for(int i = 0; i<moves.size(); i++) {
				result += moves.get(i).toString() + "\n";
				result += "====================================\n";
			}
		}
		
		result +="\nTips while using this character:";
	    result +="\n"+ usingTips + "\n";
	    result +="\nTips while facing this character:";
	    result +="\n" + dealWithTips + "\n";
	    return result;
	}
}

