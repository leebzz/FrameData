/*
 * This class is used to create the move sets for the characters,
 * and the time those moves take to perform, and how long they will
 * effect the other characters in a "stun" time.
 */

package Final;

public class Move {
	private String name;
	private String input; // the buttons needed to perform this move
	
	/*
	 * Create the variables for the times and damage that the move will 
	 * use when being performed
	 */
private double startUpTime;
	private double recoveryTime;
	private double damage;
	private double blockStunTime;
	private double hitStunTime;
	private double activeTime;
	
	public Move(String name,String input, double startUptime, double activeTime,double recorveryTime,double damage, double blockStunTime, double hitStunTime) {
		this.name=name.toUpperCase();
		this.input = input.toUpperCase();
		this.startUpTime=startUptime;
		this.recoveryTime=recorveryTime;
		this.damage=damage;
		this.blockStunTime=blockStunTime;
		this.hitStunTime = hitStunTime;
		this.activeTime=activeTime;	
		
	}
/*
 * Create the accessors and mutators for the variables
 * 
 */
	public double getActiveTime() {
		return activeTime;
	}

	public void setActiveTime(double activeTime) {
		this.activeTime = activeTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name.toUpperCase();
	}
	
	public String getInput() {
		return input;
	}
	
	public void setInput(String input) {
		this.input = input.toUpperCase();
	}

	
	public double getStartUpTime() {
		return startUpTime;
	}

	public void setStartUpTime(double startUpTime) {
		this.startUpTime = startUpTime;
	}

	public double getRecorveryTime() {
		return recoveryTime;
	}

	public void setRecorveryTime(double recorveryTime) {
		this.recoveryTime = recorveryTime;
	}

	public double getDamage() {
		return damage;
	}

	public void setDamage(double damage) {
		this.damage = damage;
	}

	public double getBlockStunTime() {
		return blockStunTime;
	}

	public void setBlockStunTime(double blockStunTime) {
		this.blockStunTime = blockStunTime;
	}
    public double getHitStunTime() {
    	return hitStunTime;
    }
    public void setHitStunTime(double hitStunTime) {
    	this.hitStunTime=hitStunTime;
    }
    
    /* end of the accessors and mutators****
     * 
     * 
     * the toString() which is called in the Runner class
     */
	public String toString() {
		String result = "";
		result += name;
		result += "\nInput to perform move: " + input + "\n";
		result += "\nStart up time: " + startUpTime;
		result += "\nActive time: " + activeTime;
		result += "\nRecovery time: " + recoveryTime;
		result += "\nDamage: " + damage;
		result += "\nBlock stun time: " + blockStunTime;
		result += "\nHit stun time: " + hitStunTime;
		return result;
		
	}
	
}