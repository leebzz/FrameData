/*
 * This class calls the methods found in the other classes to add, remove, and
 * view the characters that have been created.
 */

package Final;

import java.util.HashMap;
import java.util.Set;

public class Game {
	private HashMap<String, GameCharacter> characters;
	
	public Game() {
		characters = new HashMap<String, GameCharacter>();
	}
	
	public void addCharacter(GameCharacter character) {
		characters.put(character.getName().toLowerCase(), character);
	}
	
	public void removeCharacter(GameCharacter character) {
		characters.remove(character.getName().toLowerCase());
	}
	
	public GameCharacter getCharacter(String name) {
		return characters.get(name);
	}
	
	public Set<String> getCharacterNames(){
		return characters.keySet();
	}
	
	public int getNumCharacters() {
		return characters.size();
	}
	
}
