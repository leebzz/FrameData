/*
 * This class is the runner of the program, it will run the game
 * creating the GUI for the program and allows the user to enter 
 * inputs for the move sets that will be created for the game.
 */

package Final;

import java.util.ArrayList;
import java.util.Set;

import javax.swing.JOptionPane;

/*
 * create the runner and the game that will be called later.
 */
public class Runner {
	
	Game game;
	
	public Runner()
	{
		game = new Game();
		run();
	}
	/* 
	 * creates the run() method for the game, and will call all the methods
	 * from the other classes.
	 */
	private void run()
	{
		int choice = -1;
		do
		{
			choice = printMenu();
			if(choice == 0)
			{
				viewCharacter();
			}
		
			else if(choice == 1)
			{
				addCharacter();
			}
			else if(choice ==2)
			{
				removeCharacter();
			}
			else 
			{
				System.exit(0);
			}
			
			
		}
		while(choice !=-1 && choice !=3);
		
	}
	/*
	 * uses JOptionPane to create the GUI, 
	 * allows the user to choose options from
	 * **View Character/s, Add Character, Remove Character, or Quit 
	 */
	private int printMenu()
	{
		String[] options = {"View character/s","Add character", "Remove character", "Quit"};
		int choice = JOptionPane.showOptionDialog(null, "What would you like to do?", "Character Data", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, options, options[0]); 
		return choice;
		
	}
	
	/* 
	 * If the option selected is to view, will show the characters that have been 
	 * added to the game.
	 */
	private void viewCharacter()
	{
		GameCharacter result =selectCharacter("view");
		if(result != null) {
			String text = result.toString();
			JOptionPane.showMessageDialog(null, text);
		}
	}
	
	

	/*
	 * if the user selected to add character, will prompt the user to add
	 * the information for the character
	 */
	private void addCharacter()
	{
		String name =  JOptionPane.showInputDialog(null,"What is the name of the character?");
		while(name == null) {
			name =  JOptionPane.showInputDialog(null,"You must enter in a name for the character?");
		}
		String usingTips = JOptionPane.showInputDialog(null,"What are some tips when using this character?");
		if (usingTips == null) {
			usingTips = "NONE ENTERED";
		}
		String dealWithTips = JOptionPane.showInputDialog(null,"What are some tips when playing against this character?");
		if (dealWithTips == null) {
			dealWithTips = "NONE ENTERED";
		}
		int answer = JOptionPane.showConfirmDialog(null, "Would you like to add a move to the character?");
		ArrayList<Move> moves = new ArrayList<Move>();
		while(answer == 0) {
			moves.add(creatMove());
			answer = JOptionPane.showConfirmDialog(null, "Would you like to add another move to the character?");
			
		}
		game.addCharacter(new GameCharacter(name,moves,usingTips, dealWithTips));
		JOptionPane.showMessageDialog(null, name + " was succssfully added!");
		
	}
	
	/* 
	 * allows the user to enter the information for the move sets after the 
	 * user has entered the name and information for the character.
	 */
	private Move creatMove() {
		 String name;
		 String input; // the buttons needed to perform this move
		
		 double startUpTime;
		 double recoveryTime;
		 double damage;
		 double blockStunTime;
		 double hitStunTime;
		 double activeTime;
		 
		 name = JOptionPane.showInputDialog(null,"Enter the name of the move");
		 input = JOptionPane.showInputDialog(null,"Enter the input to do the move");
		 startUpTime = getDouble("What is the start up time of the move?");
		 recoveryTime = getDouble("What is the recorvery time of the move?");
		 damage = getDouble("How much damage does the move do?");
		 blockStunTime = getDouble("How much block stun does the move have?");
		 hitStunTime = getDouble("How much hit stun does the move have?");
		 activeTime = getDouble("How long is the move active?");
		 return new Move(name,input,startUpTime, activeTime, recoveryTime, damage,blockStunTime,hitStunTime);
	}
	private double getDouble(String prompt) {
		boolean again = true;
		String temp;
		double result = 0;
		while( again ) {
			temp = JOptionPane.showInputDialog(null,prompt);
			try {
				result = Double.parseDouble(temp);
				again = false;
			}
			catch(Exception e) {
				again = true;
				JOptionPane.showMessageDialog(null,"Invalid input try again");
			}
		}
		return result;
	}
	/*private Move creatMove() {
		System.out.println("what is the name of the move?");
		String name = input.nextLine();
		System.out.println("what is the input to preform the move?");
		String moveInput = input.nextLine();
		System.out.println("what is the startup time of the move?");
		double startUpTime = input.nextDouble();
		System.out.println("what is the active time of the move?");
		double activeTime = input.nextDouble();
		System.out.println("what is the recovery time of the move?");
		double recoveryTime = input.nextDouble();
		System.out.println("what is the damage of the move?");
		double damage = input.nextDouble();
		System.out.println("what is the block stun time of the move?");
		double blockStunTime = input.nextDouble();
		System.out.println("what is the hit stun of the move?");
		double hitStunTime = input.nextDouble();
		
		input.nextLine();
		System.out.println(name + " move has been added successfully!");
		return new Move(name,moveInput,startUpTime, activeTime, recoveryTime, damage,blockStunTime,hitStunTime);
		
	} */
	
	/*
	 * Will allow the user to remove characters that have been added to the 
	 * game.
	 */
	private void removeCharacter()
	{
		GameCharacter result = selectCharacter("remove");
		if(result != null) {
			game.removeCharacter(result);
			JOptionPane.showMessageDialog(null, "Character removed successfully!");
		}
	}
	
	private GameCharacter selectCharacter(String action) {
		if(game.getNumCharacters() > 0) {
			return validateCharacterName(displayAllCharacters(),action);
			}
		    JOptionPane.showMessageDialog(null,"There are no  characters to " + action + ".");
		    return null;
		
	}
	/*
	 * If the user tries to view a character that isn't in the game, will prompt the user
	 * to enter a valid name.
	 */
	private GameCharacter validateCharacterName(String characters, String action)
	{
		String text = "Enter the name of the character you would like to " + action + ": \n" + characters; 
		String choice = JOptionPane.showInputDialog(null, text);
		GameCharacter result = game.getCharacter(choice.toLowerCase());
		while(result == null) {
			text = "No character exists by that name! Try again: \n " + characters;
			choice = JOptionPane.showInputDialog(null, text);
			result = game.getCharacter(choice.toLowerCase());
		}
		return result;
		
	}
	/* 
	 * will show the list of characters that have been added to the game.
	 */
	private String displayAllCharacters() {
		String result = "These are the available characters: \n";
		Set<String> characterNames = game.getCharacterNames();
		for(String name : characterNames) {
			result += name + "\n";
		}
		return result;
	}
	/*
	 * void main method that will run the creator.
	 */
	public static void main (String[] args) 
	{
		new Runner();
	}

}
